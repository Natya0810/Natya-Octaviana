import React from 'react';
import { View, FlatList, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const data = [
  { 
    id: '1', 
    judul: 'Meitiasari Nurlatifah', 
    telpon: '085892775764',
    gambar: require('../assets/Memei.jpeg'),
    alamat: 'Jl. Pelda Suryanta',
  },
  { 
    id: '2', 
    judul: 'Dian Sela Anjelina', 
    telpon: '08156193245', 
    gambar: require('../assets/Dian.jpeg'),
    alamat: 'Jl. Jagaraksa Gang Amris',
  },
  { 
    id: '3', 
    judul: 'Desti Oktaviani', 
    telpon: '088809161356', 
    gambar: require('../assets/Desti.jpeg'),
    alamat: 'Jl. Gedong Panjang RT 05 RW 06',
  },
  { 
    id: '4', 
    judul: 'Agung Bahtiar', 
    telpon: '087772243468', 
    gambar: require('../assets/Agung.jpeg'),
    alamat: 'Jl. Keramat',
  },
  { 
    id: '5', 
    judul: 'Moch Azkiya', 
    telpon: '085871287578', 
    gambar: require('../assets/Azkiya.jpeg'),
    alamat: 'Jl. Cisaat',
  },
  { 
    id: '6', 
    judul: 'Rafi Maulana Putra', 
    telpon: '0857233345631', 
    gambar: require('../assets/Rafi.jpeg'),
    alamat: 'Kp.cirumput RT.05/04 des. Selaawi kec Sukaraja kab.Sukabumi ',
  },
  { 
    id: '7', 
    judul: 'Fahrizan', 
    telpon: '089517053223', 
    gambar: require('../assets/Fahrizan.jpeg'),
    alamat: 'Jl.cijangkar ',
  },
  { 
    id: '8', 
    judul: 'Artika Oktadevi', 
    telpon: '085793438973', 
    gambar: require('../assets/Artika.jpeg'),
    alamat: 'Jl.gempar',
  },
  { 
    id: '9', 
    judul: 'Noval', 
    telpon: '085723341349', 
    gambar: require('../assets/Noval.jpeg'),
    alamat: 'Jl.tegal panjang',
  },
  { 
    id: '10', 
    judul: 'Nta', 
    telpon: '081460818363', 
    gambar: require('../assets/Ita.jpeg'),
    alamat: 'Jl.Lingkar selatan',
  },
];

const KontakItem = ({ judul, telpon, gambar, alamat, onPress }) => (
  <TouchableOpacity onPress={onPress} style={styles.itemContainer}>
    <Image source={gambar} style={styles.image} />
    <View style={styles.textContainer}>
      <Text style={styles.title}>{judul}</Text>
      <Text style={styles.phone}>{telpon}</Text>
      <Text style={styles.address}>{alamat}</Text>
    </View>
  </TouchableOpacity>
);

const Kontak = ({ navigation }) => {
  const renderItem = ({ item }) => (
    <KontakItem
      judul={item.judul}
      telpon={item.telpon}
      gambar={item.gambar}
      alamat={item.alamat}
      onPress={() => navigation.navigate('KontakDetail', item)}
    />
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
        contentContainerStyle={styles.flatlistContainer}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#8A2BE2', // Warna ungu (purple)
    paddingHorizontal: 16,
    paddingTop: 24,
  },
  flatlistContainer: {
    paddingBottom: 16,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: '#F0F0F0', 
    marginBottom: 12, 
    borderRadius: 8,
    elevation: 2, 
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 30, 
  },
  textContainer: {
    marginLeft: 12,
    flex: 1,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333', 
  },
  phone: {
    fontSize: 16,
    color: '#666666', 
    marginTop: 4,
  },
  address: {
    fontSize: 14,
    color: '#999999',
    marginTop: 4,
  },
});

export default Kontak;
